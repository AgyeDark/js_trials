// selecting a country from a list of countries
// an example of for loops

let country = ['Ghana','Togo','Mali','Burkina Faso','Ivory Coast','Mauritania','Benin','Nigeria','Niger','South Africa','Cape Verde']
console.log(country)
for(i=0; i<country.length; i++){
    console.log(country[i], 'is a country in Africa')
}
